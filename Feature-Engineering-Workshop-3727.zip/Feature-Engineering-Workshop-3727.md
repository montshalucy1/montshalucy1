# Feature Engineering 

Feature Engineering is the process of transforming raw data into meaningful features that can be used as input for advanceced visualisations or machine learning algorithms.

It involves selecting, creating, and transforming features to hopefully enhance the dataset.

Poorly designed features can lead to a disruptive dataset. 


## Types of Feature Engineering

* **Handling Missing Values**

    Filling missing values with appropriate strategies, e.g., mean, median, or constant values.

* **Encoding Categorical Variables**

    Converting categorical data into numeric form, such as one-hot encoding or label encoding. Only needed if you are building a model

* **Binning Numeric Variables**

    Grouping continuous data into bins or categories to simplify the representation.

* **Feature Scaling**

    Scaling features to bring them to a similar range, e.g., Min-Max scaling or Standard scaling.

* **Creating New Features**

    Generating new features by combining or transforming existing ones.

* **Handling Outliers**

    Managing extreme values that can affect model performance.

* **Feature Joining**

    Creating new features by combining multiple existing features.

## Imports and Dataset


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
df = pd.read_csv("insurance_claims.csv")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>months_as_customer</th>
      <th>age</th>
      <th>policy_number</th>
      <th>policy_bind_date</th>
      <th>policy_state</th>
      <th>policy_csl</th>
      <th>policy_deductable</th>
      <th>policy_annual_premium</th>
      <th>umbrella_limit</th>
      <th>insured_zip</th>
      <th>...</th>
      <th>police_report_available</th>
      <th>total_claim_amount</th>
      <th>injury_claim</th>
      <th>property_claim</th>
      <th>vehicle_claim</th>
      <th>auto_make</th>
      <th>auto_model</th>
      <th>auto_year</th>
      <th>fraud_reported</th>
      <th>_c39</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>328</td>
      <td>48</td>
      <td>521585</td>
      <td>2014-10-17</td>
      <td>OH</td>
      <td>250/500</td>
      <td>1000</td>
      <td>1406.91</td>
      <td>0</td>
      <td>466132</td>
      <td>...</td>
      <td>YES</td>
      <td>71610</td>
      <td>6510</td>
      <td>13020</td>
      <td>52080</td>
      <td>Saab</td>
      <td>92x</td>
      <td>2004</td>
      <td>Y</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>228</td>
      <td>42</td>
      <td>342868</td>
      <td>2006-06-27</td>
      <td>IN</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1197.22</td>
      <td>5000000</td>
      <td>468176</td>
      <td>...</td>
      <td>?</td>
      <td>5070</td>
      <td>780</td>
      <td>780</td>
      <td>3510</td>
      <td>Mercedes</td>
      <td>E400</td>
      <td>2007</td>
      <td>Y</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>134</td>
      <td>29</td>
      <td>687698</td>
      <td>2000-09-06</td>
      <td>OH</td>
      <td>100/300</td>
      <td>2000</td>
      <td>1413.14</td>
      <td>5000000</td>
      <td>430632</td>
      <td>...</td>
      <td>NO</td>
      <td>34650</td>
      <td>7700</td>
      <td>3850</td>
      <td>23100</td>
      <td>Dodge</td>
      <td>RAM</td>
      <td>2007</td>
      <td>N</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>256</td>
      <td>41</td>
      <td>227811</td>
      <td>1990-05-25</td>
      <td>IL</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1415.74</td>
      <td>6000000</td>
      <td>608117</td>
      <td>...</td>
      <td>NO</td>
      <td>63400</td>
      <td>6340</td>
      <td>6340</td>
      <td>50720</td>
      <td>Chevrolet</td>
      <td>Tahoe</td>
      <td>2014</td>
      <td>Y</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>228</td>
      <td>44</td>
      <td>367455</td>
      <td>2014-06-06</td>
      <td>IL</td>
      <td>500/1000</td>
      <td>1000</td>
      <td>1583.91</td>
      <td>6000000</td>
      <td>610706</td>
      <td>...</td>
      <td>NO</td>
      <td>6500</td>
      <td>1300</td>
      <td>650</td>
      <td>4550</td>
      <td>Accura</td>
      <td>RSX</td>
      <td>2009</td>
      <td>N</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 40 columns</p>
</div>



### Missing Values


```python
null_counts = df.isnull().sum()
null_counts
```




    months_as_customer                0
    age                               0
    policy_number                     0
    policy_bind_date                  0
    policy_state                      0
    policy_csl                        0
    policy_deductable                 0
    policy_annual_premium             0
    umbrella_limit                    0
    insured_zip                       0
    insured_sex                       0
    insured_education_level           0
    insured_occupation                0
    insured_hobbies                   0
    insured_relationship              0
    capital-gains                     0
    capital-loss                      0
    incident_date                     0
    incident_type                     0
    collision_type                    0
    incident_severity                 0
    authorities_contacted             0
    incident_state                    0
    incident_city                     0
    incident_location                 0
    incident_hour_of_the_day          0
    number_of_vehicles_involved       0
    property_damage                   0
    bodily_injuries                   0
    witnesses                         0
    police_report_available           0
    total_claim_amount                0
    injury_claim                      0
    property_claim                    0
    vehicle_claim                     0
    auto_make                         0
    auto_model                        0
    auto_year                         0
    fraud_reported                    0
    _c39                           1000
    dtype: int64




```python
df_new = df.drop("_c39", axis = 1)
```


```python
df_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>months_as_customer</th>
      <th>age</th>
      <th>policy_number</th>
      <th>policy_bind_date</th>
      <th>policy_state</th>
      <th>policy_csl</th>
      <th>policy_deductable</th>
      <th>policy_annual_premium</th>
      <th>umbrella_limit</th>
      <th>insured_zip</th>
      <th>...</th>
      <th>witnesses</th>
      <th>police_report_available</th>
      <th>total_claim_amount</th>
      <th>injury_claim</th>
      <th>property_claim</th>
      <th>vehicle_claim</th>
      <th>auto_make</th>
      <th>auto_model</th>
      <th>auto_year</th>
      <th>fraud_reported</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>328</td>
      <td>48</td>
      <td>521585</td>
      <td>2014-10-17</td>
      <td>OH</td>
      <td>250/500</td>
      <td>1000</td>
      <td>1406.91</td>
      <td>0</td>
      <td>466132</td>
      <td>...</td>
      <td>2</td>
      <td>YES</td>
      <td>71610</td>
      <td>6510</td>
      <td>13020</td>
      <td>52080</td>
      <td>Saab</td>
      <td>92x</td>
      <td>2004</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>1</th>
      <td>228</td>
      <td>42</td>
      <td>342868</td>
      <td>2006-06-27</td>
      <td>IN</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1197.22</td>
      <td>5000000</td>
      <td>468176</td>
      <td>...</td>
      <td>0</td>
      <td>?</td>
      <td>5070</td>
      <td>780</td>
      <td>780</td>
      <td>3510</td>
      <td>Mercedes</td>
      <td>E400</td>
      <td>2007</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>2</th>
      <td>134</td>
      <td>29</td>
      <td>687698</td>
      <td>2000-09-06</td>
      <td>OH</td>
      <td>100/300</td>
      <td>2000</td>
      <td>1413.14</td>
      <td>5000000</td>
      <td>430632</td>
      <td>...</td>
      <td>3</td>
      <td>NO</td>
      <td>34650</td>
      <td>7700</td>
      <td>3850</td>
      <td>23100</td>
      <td>Dodge</td>
      <td>RAM</td>
      <td>2007</td>
      <td>N</td>
    </tr>
    <tr>
      <th>3</th>
      <td>256</td>
      <td>41</td>
      <td>227811</td>
      <td>1990-05-25</td>
      <td>IL</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1415.74</td>
      <td>6000000</td>
      <td>608117</td>
      <td>...</td>
      <td>2</td>
      <td>NO</td>
      <td>63400</td>
      <td>6340</td>
      <td>6340</td>
      <td>50720</td>
      <td>Chevrolet</td>
      <td>Tahoe</td>
      <td>2014</td>
      <td>Y</td>
    </tr>
    <tr>
      <th>4</th>
      <td>228</td>
      <td>44</td>
      <td>367455</td>
      <td>2014-06-06</td>
      <td>IL</td>
      <td>500/1000</td>
      <td>1000</td>
      <td>1583.91</td>
      <td>6000000</td>
      <td>610706</td>
      <td>...</td>
      <td>1</td>
      <td>NO</td>
      <td>6500</td>
      <td>1300</td>
      <td>650</td>
      <td>4550</td>
      <td>Accura</td>
      <td>RSX</td>
      <td>2009</td>
      <td>N</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 39 columns</p>
</div>



### Binding Numeric Data


```python
df_new.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>months_as_customer</th>
      <th>age</th>
      <th>policy_number</th>
      <th>policy_deductable</th>
      <th>policy_annual_premium</th>
      <th>umbrella_limit</th>
      <th>insured_zip</th>
      <th>capital-gains</th>
      <th>capital-loss</th>
      <th>incident_hour_of_the_day</th>
      <th>number_of_vehicles_involved</th>
      <th>bodily_injuries</th>
      <th>witnesses</th>
      <th>total_claim_amount</th>
      <th>injury_claim</th>
      <th>property_claim</th>
      <th>vehicle_claim</th>
      <th>auto_year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1.000000e+03</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.00000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.00000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>203.954000</td>
      <td>38.948000</td>
      <td>546238.648000</td>
      <td>1136.000000</td>
      <td>1256.406150</td>
      <td>1.101000e+06</td>
      <td>501214.488000</td>
      <td>25126.100000</td>
      <td>-26793.700000</td>
      <td>11.644000</td>
      <td>1.83900</td>
      <td>0.992000</td>
      <td>1.487000</td>
      <td>52761.94000</td>
      <td>7433.420000</td>
      <td>7399.570000</td>
      <td>37928.950000</td>
      <td>2005.103000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>115.113174</td>
      <td>9.140287</td>
      <td>257063.005276</td>
      <td>611.864673</td>
      <td>244.167395</td>
      <td>2.297407e+06</td>
      <td>71701.610941</td>
      <td>27872.187708</td>
      <td>28104.096686</td>
      <td>6.951373</td>
      <td>1.01888</td>
      <td>0.820127</td>
      <td>1.111335</td>
      <td>26401.53319</td>
      <td>4880.951853</td>
      <td>4824.726179</td>
      <td>18886.252893</td>
      <td>6.015861</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>19.000000</td>
      <td>100804.000000</td>
      <td>500.000000</td>
      <td>433.330000</td>
      <td>-1.000000e+06</td>
      <td>430104.000000</td>
      <td>0.000000</td>
      <td>-111100.000000</td>
      <td>0.000000</td>
      <td>1.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>100.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>70.000000</td>
      <td>1995.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>115.750000</td>
      <td>32.000000</td>
      <td>335980.250000</td>
      <td>500.000000</td>
      <td>1089.607500</td>
      <td>0.000000e+00</td>
      <td>448404.500000</td>
      <td>0.000000</td>
      <td>-51500.000000</td>
      <td>6.000000</td>
      <td>1.00000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>41812.50000</td>
      <td>4295.000000</td>
      <td>4445.000000</td>
      <td>30292.500000</td>
      <td>2000.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>199.500000</td>
      <td>38.000000</td>
      <td>533135.000000</td>
      <td>1000.000000</td>
      <td>1257.200000</td>
      <td>0.000000e+00</td>
      <td>466445.500000</td>
      <td>0.000000</td>
      <td>-23250.000000</td>
      <td>12.000000</td>
      <td>1.00000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>58055.00000</td>
      <td>6775.000000</td>
      <td>6750.000000</td>
      <td>42100.000000</td>
      <td>2005.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>276.250000</td>
      <td>44.000000</td>
      <td>759099.750000</td>
      <td>2000.000000</td>
      <td>1415.695000</td>
      <td>0.000000e+00</td>
      <td>603251.000000</td>
      <td>51025.000000</td>
      <td>0.000000</td>
      <td>17.000000</td>
      <td>3.00000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>70592.50000</td>
      <td>11305.000000</td>
      <td>10885.000000</td>
      <td>50822.500000</td>
      <td>2010.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>479.000000</td>
      <td>64.000000</td>
      <td>999435.000000</td>
      <td>2000.000000</td>
      <td>2047.590000</td>
      <td>1.000000e+07</td>
      <td>620962.000000</td>
      <td>100500.000000</td>
      <td>0.000000</td>
      <td>23.000000</td>
      <td>4.00000</td>
      <td>2.000000</td>
      <td>3.000000</td>
      <td>114920.00000</td>
      <td>21450.000000</td>
      <td>23670.000000</td>
      <td>79560.000000</td>
      <td>2015.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Choose the column for the histogram
column_name = 'age'

# Plot the histogram
plt.hist(df[column_name], bins=3, edgecolor='black')

# Add labels and title
plt.xlabel(column_name)
plt.ylabel('Frequency')
plt.title(f'Histogram of {column_name}')

# Display the histogram
plt.show()
```


    
![png](output_12_0.png)
    



```python
bin_edges = [0, 30, 55, 100]  # Define the bin edges
bin_labels = ['Young Adult', 'Middle Aged', 'Elderly']  # Corresponding labels for each bin

# Create a new column based on the bin labels
df_new['ages_category'] = pd.cut(df_new['age'], bins=bin_edges, labels=bin_labels)
```


```python
df_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>months_as_customer</th>
      <th>age</th>
      <th>policy_number</th>
      <th>policy_bind_date</th>
      <th>policy_state</th>
      <th>policy_csl</th>
      <th>policy_deductable</th>
      <th>policy_annual_premium</th>
      <th>umbrella_limit</th>
      <th>insured_zip</th>
      <th>...</th>
      <th>police_report_available</th>
      <th>total_claim_amount</th>
      <th>injury_claim</th>
      <th>property_claim</th>
      <th>vehicle_claim</th>
      <th>auto_make</th>
      <th>auto_model</th>
      <th>auto_year</th>
      <th>fraud_reported</th>
      <th>ages_category</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>328</td>
      <td>48</td>
      <td>521585</td>
      <td>2014-10-17</td>
      <td>OH</td>
      <td>250/500</td>
      <td>1000</td>
      <td>1406.91</td>
      <td>0</td>
      <td>466132</td>
      <td>...</td>
      <td>YES</td>
      <td>71610</td>
      <td>6510</td>
      <td>13020</td>
      <td>52080</td>
      <td>Saab</td>
      <td>92x</td>
      <td>2004</td>
      <td>Y</td>
      <td>Middle Aged</td>
    </tr>
    <tr>
      <th>1</th>
      <td>228</td>
      <td>42</td>
      <td>342868</td>
      <td>2006-06-27</td>
      <td>IN</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1197.22</td>
      <td>5000000</td>
      <td>468176</td>
      <td>...</td>
      <td>?</td>
      <td>5070</td>
      <td>780</td>
      <td>780</td>
      <td>3510</td>
      <td>Mercedes</td>
      <td>E400</td>
      <td>2007</td>
      <td>Y</td>
      <td>Middle Aged</td>
    </tr>
    <tr>
      <th>2</th>
      <td>134</td>
      <td>29</td>
      <td>687698</td>
      <td>2000-09-06</td>
      <td>OH</td>
      <td>100/300</td>
      <td>2000</td>
      <td>1413.14</td>
      <td>5000000</td>
      <td>430632</td>
      <td>...</td>
      <td>NO</td>
      <td>34650</td>
      <td>7700</td>
      <td>3850</td>
      <td>23100</td>
      <td>Dodge</td>
      <td>RAM</td>
      <td>2007</td>
      <td>N</td>
      <td>Young Adult</td>
    </tr>
    <tr>
      <th>3</th>
      <td>256</td>
      <td>41</td>
      <td>227811</td>
      <td>1990-05-25</td>
      <td>IL</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1415.74</td>
      <td>6000000</td>
      <td>608117</td>
      <td>...</td>
      <td>NO</td>
      <td>63400</td>
      <td>6340</td>
      <td>6340</td>
      <td>50720</td>
      <td>Chevrolet</td>
      <td>Tahoe</td>
      <td>2014</td>
      <td>Y</td>
      <td>Middle Aged</td>
    </tr>
    <tr>
      <th>4</th>
      <td>228</td>
      <td>44</td>
      <td>367455</td>
      <td>2014-06-06</td>
      <td>IL</td>
      <td>500/1000</td>
      <td>1000</td>
      <td>1583.91</td>
      <td>6000000</td>
      <td>610706</td>
      <td>...</td>
      <td>NO</td>
      <td>6500</td>
      <td>1300</td>
      <td>650</td>
      <td>4550</td>
      <td>Accura</td>
      <td>RSX</td>
      <td>2009</td>
      <td>N</td>
      <td>Middle Aged</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 40 columns</p>
</div>




```python
bin_edges_customer = [0, 25, 150, 500]  # Define the bin edges
bin_labels_customer = ['New Client', 'Established Client', 'Long-Term Client']  # Corresponding labels for each bin

# Create a new column based on the bin labels
df_new['customer_category'] = pd.cut(df_new['months_as_customer'], bins=bin_edges_customer, labels=bin_labels_customer)
```


```python
df_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>months_as_customer</th>
      <th>age</th>
      <th>policy_number</th>
      <th>policy_bind_date</th>
      <th>policy_state</th>
      <th>policy_csl</th>
      <th>policy_deductable</th>
      <th>policy_annual_premium</th>
      <th>umbrella_limit</th>
      <th>insured_zip</th>
      <th>...</th>
      <th>total_claim_amount</th>
      <th>injury_claim</th>
      <th>property_claim</th>
      <th>vehicle_claim</th>
      <th>auto_make</th>
      <th>auto_model</th>
      <th>auto_year</th>
      <th>fraud_reported</th>
      <th>ages_category</th>
      <th>customer_category</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>328</td>
      <td>48</td>
      <td>521585</td>
      <td>2014-10-17</td>
      <td>OH</td>
      <td>250/500</td>
      <td>1000</td>
      <td>1406.91</td>
      <td>0</td>
      <td>466132</td>
      <td>...</td>
      <td>71610</td>
      <td>6510</td>
      <td>13020</td>
      <td>52080</td>
      <td>Saab</td>
      <td>92x</td>
      <td>2004</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
    </tr>
    <tr>
      <th>1</th>
      <td>228</td>
      <td>42</td>
      <td>342868</td>
      <td>2006-06-27</td>
      <td>IN</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1197.22</td>
      <td>5000000</td>
      <td>468176</td>
      <td>...</td>
      <td>5070</td>
      <td>780</td>
      <td>780</td>
      <td>3510</td>
      <td>Mercedes</td>
      <td>E400</td>
      <td>2007</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
    </tr>
    <tr>
      <th>2</th>
      <td>134</td>
      <td>29</td>
      <td>687698</td>
      <td>2000-09-06</td>
      <td>OH</td>
      <td>100/300</td>
      <td>2000</td>
      <td>1413.14</td>
      <td>5000000</td>
      <td>430632</td>
      <td>...</td>
      <td>34650</td>
      <td>7700</td>
      <td>3850</td>
      <td>23100</td>
      <td>Dodge</td>
      <td>RAM</td>
      <td>2007</td>
      <td>N</td>
      <td>Young Adult</td>
      <td>Established Client</td>
    </tr>
    <tr>
      <th>3</th>
      <td>256</td>
      <td>41</td>
      <td>227811</td>
      <td>1990-05-25</td>
      <td>IL</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1415.74</td>
      <td>6000000</td>
      <td>608117</td>
      <td>...</td>
      <td>63400</td>
      <td>6340</td>
      <td>6340</td>
      <td>50720</td>
      <td>Chevrolet</td>
      <td>Tahoe</td>
      <td>2014</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
    </tr>
    <tr>
      <th>4</th>
      <td>228</td>
      <td>44</td>
      <td>367455</td>
      <td>2014-06-06</td>
      <td>IL</td>
      <td>500/1000</td>
      <td>1000</td>
      <td>1583.91</td>
      <td>6000000</td>
      <td>610706</td>
      <td>...</td>
      <td>6500</td>
      <td>1300</td>
      <td>650</td>
      <td>4550</td>
      <td>Accura</td>
      <td>RSX</td>
      <td>2009</td>
      <td>N</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 41 columns</p>
</div>



## Creating New Features


```python
df_new["Contract Years"] = df_new["months_as_customer"]/12
```


```python
df_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>months_as_customer</th>
      <th>age</th>
      <th>policy_number</th>
      <th>policy_bind_date</th>
      <th>policy_state</th>
      <th>policy_csl</th>
      <th>policy_deductable</th>
      <th>policy_annual_premium</th>
      <th>umbrella_limit</th>
      <th>insured_zip</th>
      <th>...</th>
      <th>injury_claim</th>
      <th>property_claim</th>
      <th>vehicle_claim</th>
      <th>auto_make</th>
      <th>auto_model</th>
      <th>auto_year</th>
      <th>fraud_reported</th>
      <th>ages_category</th>
      <th>customer_category</th>
      <th>Contract Years</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>328</td>
      <td>48</td>
      <td>521585</td>
      <td>2014-10-17</td>
      <td>OH</td>
      <td>250/500</td>
      <td>1000</td>
      <td>1406.91</td>
      <td>0</td>
      <td>466132</td>
      <td>...</td>
      <td>6510</td>
      <td>13020</td>
      <td>52080</td>
      <td>Saab</td>
      <td>92x</td>
      <td>2004</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>27.333333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>228</td>
      <td>42</td>
      <td>342868</td>
      <td>2006-06-27</td>
      <td>IN</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1197.22</td>
      <td>5000000</td>
      <td>468176</td>
      <td>...</td>
      <td>780</td>
      <td>780</td>
      <td>3510</td>
      <td>Mercedes</td>
      <td>E400</td>
      <td>2007</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>19.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>134</td>
      <td>29</td>
      <td>687698</td>
      <td>2000-09-06</td>
      <td>OH</td>
      <td>100/300</td>
      <td>2000</td>
      <td>1413.14</td>
      <td>5000000</td>
      <td>430632</td>
      <td>...</td>
      <td>7700</td>
      <td>3850</td>
      <td>23100</td>
      <td>Dodge</td>
      <td>RAM</td>
      <td>2007</td>
      <td>N</td>
      <td>Young Adult</td>
      <td>Established Client</td>
      <td>11.166667</td>
    </tr>
    <tr>
      <th>3</th>
      <td>256</td>
      <td>41</td>
      <td>227811</td>
      <td>1990-05-25</td>
      <td>IL</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1415.74</td>
      <td>6000000</td>
      <td>608117</td>
      <td>...</td>
      <td>6340</td>
      <td>6340</td>
      <td>50720</td>
      <td>Chevrolet</td>
      <td>Tahoe</td>
      <td>2014</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>21.333333</td>
    </tr>
    <tr>
      <th>4</th>
      <td>228</td>
      <td>44</td>
      <td>367455</td>
      <td>2014-06-06</td>
      <td>IL</td>
      <td>500/1000</td>
      <td>1000</td>
      <td>1583.91</td>
      <td>6000000</td>
      <td>610706</td>
      <td>...</td>
      <td>1300</td>
      <td>650</td>
      <td>4550</td>
      <td>Accura</td>
      <td>RSX</td>
      <td>2009</td>
      <td>N</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>19.000000</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 42 columns</p>
</div>



## Feature Joining


```python
df_new['total_premiums_paid'] = (df_new['policy_annual_premium']/12) * df_new['months_as_customer']
```


```python
df_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>months_as_customer</th>
      <th>age</th>
      <th>policy_number</th>
      <th>policy_bind_date</th>
      <th>policy_state</th>
      <th>policy_csl</th>
      <th>policy_deductable</th>
      <th>policy_annual_premium</th>
      <th>umbrella_limit</th>
      <th>insured_zip</th>
      <th>...</th>
      <th>property_claim</th>
      <th>vehicle_claim</th>
      <th>auto_make</th>
      <th>auto_model</th>
      <th>auto_year</th>
      <th>fraud_reported</th>
      <th>ages_category</th>
      <th>customer_category</th>
      <th>Contract Years</th>
      <th>total_premiums_paid</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>328</td>
      <td>48</td>
      <td>521585</td>
      <td>2014-10-17</td>
      <td>OH</td>
      <td>250/500</td>
      <td>1000</td>
      <td>1406.91</td>
      <td>0</td>
      <td>466132</td>
      <td>...</td>
      <td>13020</td>
      <td>52080</td>
      <td>Saab</td>
      <td>92x</td>
      <td>2004</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>27.333333</td>
      <td>38455.540000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>228</td>
      <td>42</td>
      <td>342868</td>
      <td>2006-06-27</td>
      <td>IN</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1197.22</td>
      <td>5000000</td>
      <td>468176</td>
      <td>...</td>
      <td>780</td>
      <td>3510</td>
      <td>Mercedes</td>
      <td>E400</td>
      <td>2007</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>19.000000</td>
      <td>22747.180000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>134</td>
      <td>29</td>
      <td>687698</td>
      <td>2000-09-06</td>
      <td>OH</td>
      <td>100/300</td>
      <td>2000</td>
      <td>1413.14</td>
      <td>5000000</td>
      <td>430632</td>
      <td>...</td>
      <td>3850</td>
      <td>23100</td>
      <td>Dodge</td>
      <td>RAM</td>
      <td>2007</td>
      <td>N</td>
      <td>Young Adult</td>
      <td>Established Client</td>
      <td>11.166667</td>
      <td>15780.063333</td>
    </tr>
    <tr>
      <th>3</th>
      <td>256</td>
      <td>41</td>
      <td>227811</td>
      <td>1990-05-25</td>
      <td>IL</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1415.74</td>
      <td>6000000</td>
      <td>608117</td>
      <td>...</td>
      <td>6340</td>
      <td>50720</td>
      <td>Chevrolet</td>
      <td>Tahoe</td>
      <td>2014</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>21.333333</td>
      <td>30202.453333</td>
    </tr>
    <tr>
      <th>4</th>
      <td>228</td>
      <td>44</td>
      <td>367455</td>
      <td>2014-06-06</td>
      <td>IL</td>
      <td>500/1000</td>
      <td>1000</td>
      <td>1583.91</td>
      <td>6000000</td>
      <td>610706</td>
      <td>...</td>
      <td>650</td>
      <td>4550</td>
      <td>Accura</td>
      <td>RSX</td>
      <td>2009</td>
      <td>N</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>19.000000</td>
      <td>30094.290000</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 43 columns</p>
</div>




```python
df_new['net_value_of_customer'] = df_new['total_premiums_paid'] - df_new['total_claim_amount']
```


```python
df_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>months_as_customer</th>
      <th>age</th>
      <th>policy_number</th>
      <th>policy_bind_date</th>
      <th>policy_state</th>
      <th>policy_csl</th>
      <th>policy_deductable</th>
      <th>policy_annual_premium</th>
      <th>umbrella_limit</th>
      <th>insured_zip</th>
      <th>...</th>
      <th>vehicle_claim</th>
      <th>auto_make</th>
      <th>auto_model</th>
      <th>auto_year</th>
      <th>fraud_reported</th>
      <th>ages_category</th>
      <th>customer_category</th>
      <th>Contract Years</th>
      <th>total_premiums_paid</th>
      <th>net_value_of_customer</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>328</td>
      <td>48</td>
      <td>521585</td>
      <td>2014-10-17</td>
      <td>OH</td>
      <td>250/500</td>
      <td>1000</td>
      <td>1406.91</td>
      <td>0</td>
      <td>466132</td>
      <td>...</td>
      <td>52080</td>
      <td>Saab</td>
      <td>92x</td>
      <td>2004</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>27.333333</td>
      <td>38455.540000</td>
      <td>-33154.460000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>228</td>
      <td>42</td>
      <td>342868</td>
      <td>2006-06-27</td>
      <td>IN</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1197.22</td>
      <td>5000000</td>
      <td>468176</td>
      <td>...</td>
      <td>3510</td>
      <td>Mercedes</td>
      <td>E400</td>
      <td>2007</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>19.000000</td>
      <td>22747.180000</td>
      <td>17677.180000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>134</td>
      <td>29</td>
      <td>687698</td>
      <td>2000-09-06</td>
      <td>OH</td>
      <td>100/300</td>
      <td>2000</td>
      <td>1413.14</td>
      <td>5000000</td>
      <td>430632</td>
      <td>...</td>
      <td>23100</td>
      <td>Dodge</td>
      <td>RAM</td>
      <td>2007</td>
      <td>N</td>
      <td>Young Adult</td>
      <td>Established Client</td>
      <td>11.166667</td>
      <td>15780.063333</td>
      <td>-18869.936667</td>
    </tr>
    <tr>
      <th>3</th>
      <td>256</td>
      <td>41</td>
      <td>227811</td>
      <td>1990-05-25</td>
      <td>IL</td>
      <td>250/500</td>
      <td>2000</td>
      <td>1415.74</td>
      <td>6000000</td>
      <td>608117</td>
      <td>...</td>
      <td>50720</td>
      <td>Chevrolet</td>
      <td>Tahoe</td>
      <td>2014</td>
      <td>Y</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>21.333333</td>
      <td>30202.453333</td>
      <td>-33197.546667</td>
    </tr>
    <tr>
      <th>4</th>
      <td>228</td>
      <td>44</td>
      <td>367455</td>
      <td>2014-06-06</td>
      <td>IL</td>
      <td>500/1000</td>
      <td>1000</td>
      <td>1583.91</td>
      <td>6000000</td>
      <td>610706</td>
      <td>...</td>
      <td>4550</td>
      <td>Accura</td>
      <td>RSX</td>
      <td>2009</td>
      <td>N</td>
      <td>Middle Aged</td>
      <td>Long-Term Client</td>
      <td>19.000000</td>
      <td>30094.290000</td>
      <td>23594.290000</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 44 columns</p>
</div>



## Saving the csv for late


```python
df_new.to_csv('Advanced Features Claims Data.csv')
```

## Go wild

Go out a see what other features you can create that will be useful for our visualisations


```python

```
